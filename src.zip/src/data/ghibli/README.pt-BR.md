# Studio Ghibli

Studio Ghibli é um estúdio japonês de animação, muito
conhecido por seus filmes como **Meu Amigo Totoro**,
**A Viagem de Chihiro**, **O Castelo Animado**, entre outros grandes sucessos.
As animações são bem recebidas em todo o mundo e algumas receberam
várias nomeações e prêmios. De todo esse fandom há um grupo que deseja
interagir e ver as informações das animações e seus personagens.

## Achados

Para entender melhor quais informações nossos usuários podem precisar,
fizemos uma investigação rápida (research) e essas são algumas das conclusões.

- Studio Ghibli tem várias animações e para nossos usuários é importante
saber quantas e quais são
- As mentes por trás de cada animação são os diretores e produtores,
sendo que eles podem ter contribuído
na criação de mais de uma obra. Portanto, é importante
para nosso usuário poder conhecê-los e saber quantas e quais são as criações
em que eles trabalharam
- As animações possuem informações relevantes para nossos usuários, como
descrição, data de lançamento, diretor, produtor e personagens
- Cada animação tem seus personagens e para nossos usuários é importante
saber quantos e quais são
- Os personagens têm características únicas que o usuário deseja conhecer, como
nome, idade, sexo, espécie, etc.
- As animações têm locais e veículos únicos em cada um e para nossos usuários é
importante saber quais são
- Além dessas informações, é importante que nossos usuários sejam capazes de
ver os tipos de espécies em cada animação
